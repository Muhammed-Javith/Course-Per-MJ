package com.pwskills.service;

public class WishMessageService {
	public String wishMsg(String user) {
		return "Good Morning :: " + user;
	}
}
