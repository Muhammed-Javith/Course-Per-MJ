// Can we overload main method in Java?


public class LaunchMOMain {

	public static void main(String[] args) 
	{
		
		System.out.println("Its actual main method ");

	}
	public static void main(int [] args) 
	{
		
		System.out.println("accepting int args ");

	}
	public static void main(double b) 
	{
		
		System.out.println(" double value");

	}
	
	

}
