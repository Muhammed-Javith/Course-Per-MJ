
public class Launch11 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		
		int a[]= {10,20,30,40};
		
		for(int elem:a)
		{
			System.out.println(elem);
		}
		
		

	}

}
