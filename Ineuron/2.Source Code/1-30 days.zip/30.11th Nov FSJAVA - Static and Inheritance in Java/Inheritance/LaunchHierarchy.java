
class Demo111
{
	String name="Hyder";
	int age=28;
	
	void disp()
	{
		System.out.println("Demo111 "+ age + name);
	}
}

class Demo112 extends Demo111
{
	
}
class Demo113 extends Demo111
{
	
}
class Demo114 extends Demo112
{
	
}


public class LaunchHierarchy {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
