
public class LaunchAr {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		
		int[] ar= {10,20,30,40};
		
		for(int i=ar.length-1; i>=0 ;i--)
		{
			System.out.print(ar[i] + " ");
		}
	}

}
