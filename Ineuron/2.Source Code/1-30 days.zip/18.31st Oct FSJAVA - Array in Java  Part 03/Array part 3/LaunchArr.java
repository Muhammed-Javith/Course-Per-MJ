
public class LaunchArr {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		int[] ar= {10,20,30,40,50,70};
		
		for(int i=0;i<ar.length;i++)
		{
			System.out.print(ar[i] + " ");
			++i;
		}
	}

}
