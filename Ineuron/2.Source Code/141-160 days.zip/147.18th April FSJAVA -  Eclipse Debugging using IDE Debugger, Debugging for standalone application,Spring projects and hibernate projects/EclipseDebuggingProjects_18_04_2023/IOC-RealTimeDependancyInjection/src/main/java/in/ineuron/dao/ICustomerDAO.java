package in.ineuron.dao;

import in.ineuron.bo.CustomerBO;

public interface ICustomerDAO {
	public abstract int insert(CustomerBO bo);
}
