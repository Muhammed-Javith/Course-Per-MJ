package com.ineuron.binding;

import lombok.Data;

@Data
public class Books 
{
	
	private String bname;
	private String authorName;
	private String bprice;

}
