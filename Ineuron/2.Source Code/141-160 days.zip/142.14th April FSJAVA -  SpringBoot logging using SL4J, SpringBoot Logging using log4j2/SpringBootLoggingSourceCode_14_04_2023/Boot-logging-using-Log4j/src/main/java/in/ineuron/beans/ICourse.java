package in.ineuron.beans;

//Java,DotNet,UI
public interface ICourse {

	public String courseContent();

	public float price();
}
