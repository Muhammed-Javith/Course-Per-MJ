package in.ineuron.test;

public class StudentApp {

	public static void main(String[] args) {

		

	}
}

