package in.ineuron;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class StockActuatorsAppApplication {

	public static void main(String[] args) {
		SpringApplication.run(StockActuatorsAppApplication.class, args);
	}

}
