package in.ineuron.dao;

import java.util.List;

import in.ineuron.model.InsurancePolicy;

public class InsurancePolicyDaoImpl implements InsurancePolicyDao {

	@Override
	public List<InsurancePolicy> getPageData(int pageSize, int startPos) {
		return null;
	}

	@Override
	public Long getTotalRecordsCount() {
		return null;
	}

}
