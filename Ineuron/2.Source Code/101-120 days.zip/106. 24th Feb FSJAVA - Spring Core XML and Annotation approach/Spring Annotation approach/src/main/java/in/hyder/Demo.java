package in.hyder;

import org.springframework.stereotype.Repository;

@Repository
public class Demo 
{
	public Demo()
	{
		System.out.println("Demo obj created");
	}

}
