package ai.neuron.beans;

public interface Courses 
{
	boolean courseSelection();

}
