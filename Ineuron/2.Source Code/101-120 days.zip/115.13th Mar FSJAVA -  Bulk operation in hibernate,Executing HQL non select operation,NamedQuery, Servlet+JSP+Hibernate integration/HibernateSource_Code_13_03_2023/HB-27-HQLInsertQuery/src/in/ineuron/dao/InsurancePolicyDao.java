package in.ineuron.dao;

public interface InsurancePolicyDao {
	public abstract String transferPolicies(int minTenure);
}
