package ai.ineuron.cards;

public interface ICards 
{
	boolean payingBill(Double bill);

}
