package ai.ineuron.beans;

public interface IPay {
	
	boolean payBill(Double amt);

}
