

//NORTH SOUTH EAST WEST
//MALE FEMALE OTHERS
// SUN MON TUE WED THU FRI SAT 
//JAN FEB MAR ------ DEC
// PASS FAIL NR
// so on.......

enum Result1
{
	PASS, FAIL, NR;  // static final 
	// fields --> instance var --> properties
	//methods
	//Constructor
}
//enum Gender
//{
//	MALE, FEMALE, OTHERS;
//}
//enum Compass
//{
//	NORTH, SOUTH, EAST, WEST;
//}

//class Demo
//{
//	//final int PASS=35;
//	//PASS --> error
//}

// separte .clas for every enum 

public class LaunchEnum 
{
//	enum Gender
//	{
//		MALE, FEMALE, OTHERS;
//	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
