import java.util.*;
public class LaunchMapM 
{
	public static void main(String[] args) 
	{
		
		Integer i1=new Integer(10);
	
		Integer i2=new Integer(20);
		Integer i3=new Integer(30);
		
		HashMap hm=new HashMap();
		hm.put(i1, "Rahul");
		hm.put(i2, "Rohan");
		hm.put(i3, "Rohit");
		
		System.out.println(hm);

	}

}
