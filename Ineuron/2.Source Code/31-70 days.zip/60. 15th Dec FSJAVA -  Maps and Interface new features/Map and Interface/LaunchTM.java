import java.util.*;
public class LaunchTM {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		TreeMap tm=new TreeMap();
		
		tm.put(14, "Rohan");
		tm.put(12, "Rohit");
		tm.put(11, "Hyder");
		
		System.out.println(tm);

	}

}
