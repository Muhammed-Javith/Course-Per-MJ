package in.ineuron.dao;

import in.ineuron.bo.EmployeeBO;

public interface IEmployeeDAO {
	public EmployeeBO save(EmployeeBO bo);
}
