package in.ineuron.persistence;

import in.ineuron.dto.Student;

//Persistence logic using JDBC API
public class StudentDaoImpl implements IStudentDao {

	@Override
	public String addStudent(String sname, Integer sage, String saddress) {
		return null;
	}

	@Override
	public Student searchStudent(Integer sid) {
		return null;
	}

	@Override
	public String updateStudent(Integer sid, String sname, Integer sage, String saddress) {
		return null;
	}

	@Override
	public String deleteStudent(Integer sid) {
		return null;
	}

}
