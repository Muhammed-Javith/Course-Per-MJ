// coded by @Aman sharma 18 Aug
const projectName = 'product-landing-page';
localStorage.setItem('example_project', 'Product Landing Page');
// REPLACE CDN WITH GITCDN!!!