## 3. Build a Product Landing Page
###### Website link (Live Preview) https://codepen.io/aman22sharma/full/wvwWPZY

![screencapture-s-codepen-io-aman22sharma-debug-wvwWPZY-gareYzOVZaLr-2019-08-18-00_59_02](https://user-images.githubusercontent.com/40789486/73196175-25c64d80-4155-11ea-83e4-83ffa9d2e42c.png)
