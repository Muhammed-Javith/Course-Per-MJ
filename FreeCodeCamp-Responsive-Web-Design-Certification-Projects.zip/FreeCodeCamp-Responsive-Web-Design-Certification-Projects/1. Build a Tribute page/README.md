## 1. Build a Tribute Page
###### Website link (Live Preview) https://codepen.io/aman22sharma/full/BXxwdd

![Tribute-page](https://user-images.githubusercontent.com/40789486/73194289-fcf08900-4151-11ea-8704-b3c16a769062.png)
