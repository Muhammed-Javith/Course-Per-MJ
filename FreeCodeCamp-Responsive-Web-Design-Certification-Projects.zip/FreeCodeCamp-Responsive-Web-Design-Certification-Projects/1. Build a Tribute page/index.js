// coded by @Aman kumar sharma 8 Aug 2019

const projectName = 'tribute-page';
localStorage.setItem('example_project', 'Tribute Page');
