## 4. Build a Technical Documentation Page
###### Website link (Live Preview) https://codepen.io/aman22sharma/full/VwZjqbQ

![doce](https://user-images.githubusercontent.com/40789486/73196798-3fb46000-4156-11ea-9ba1-c72f7f760f87.png)
