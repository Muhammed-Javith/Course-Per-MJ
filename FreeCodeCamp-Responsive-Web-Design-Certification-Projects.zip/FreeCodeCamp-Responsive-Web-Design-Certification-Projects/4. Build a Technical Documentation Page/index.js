// coded by @Aman sharma 19 Aug 2019

const projectName = 'technical-docs-page';
localStorage.setItem('example_project', 'Technical Docs Page');