// coded by @Aman sharma 20 Aug 2019

const projectName = 'Personal portfolio';
localStorage.setItem('example_project', 'Technical Docs Page');