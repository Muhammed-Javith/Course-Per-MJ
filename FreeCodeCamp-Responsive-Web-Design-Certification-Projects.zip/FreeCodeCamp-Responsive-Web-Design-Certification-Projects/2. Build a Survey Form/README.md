## 2. Build a Survey Form 
This is a HTML5 Responsive Validation Form
###### Website link (Live Preview) https://codepen.io/aman22sharma/full/ymjxqX

![survey-form](https://user-images.githubusercontent.com/40789486/73195511-fc58f200-4153-11ea-94d5-31a8d0ad7516.png)
