// coded by @Aman kumar sharma 9 Aug 2020
const projectName = 'survey-form';
localStorage.setItem('example_project', 'Survey Form');